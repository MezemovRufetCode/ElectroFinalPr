Copyright (c)2008-present Jānis Skarnelis.

Portions of this software are licensed as follows:

- All content residing under the "docs/" directory of this repository is licensed under "Creative Commons: CC BY-SA 4.0 license".
- Content outside of the above mentioned directory is licensed under the Fancyapps UI license. To use this software, you need to agree to the "License Agreement" for Fancyapps UI.

All available Fancyapps licenses may be obtained at http://www.fancyapps.com/pricing.
